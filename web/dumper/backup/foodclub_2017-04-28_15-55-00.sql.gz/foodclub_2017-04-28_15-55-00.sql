#SXD20|20011|50718|50630|2017.04.28 15:55:00|foodclub|0|2|29|
#TA attachment`23`16384|document`6`16384
#EOH

#	TC`attachment`utf8_general_ci	;
CREATE TABLE `attachment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filesize` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `doc_id` (`document_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8 COMMENT='Прикреплённые файлы'	;
#	TD`attachment`utf8_general_ci	;
INSERT INTO `attachment` VALUES 
(1,'351531_image.jpg','eMWxd-PI4M6gdurpufHV5M.jpg',223547,1),
(2,'archive.zip','lE-lUfmQIgaZCm9FvH3Xos.zip',372,1),
(3,'Excel cells.xlsx','Em52fV9cmt3mXLpUCYWK4H.xlsx',2,1),
(4,'Nungnung-waterfall-Hello-Travel-1200x800.jpg','8l8bGFeUauuatKACp52h2S.jpg',333265,1),
(5,'places in the world.jpg','h9HCgVKI5WqgfDPfU46kFj.jpg',242270,1),
(6,'Excel cells.xlsx','1vrPrObURXTRZn3QIht34g.xlsx',2,2),
(7,'yii_bat_file.txt','ZOluYPunw_d4BXExDN-j0O.txt',515,2),
(8,'Nungnung-waterfall-Hello-Travel-1200x800.jpg','o3ar7Qbg99nykB4vHUQr_z.jpg',333265,4),
(9,'Some document.doc','ETKBQQvOb7Sypd_BhbLZ0O.doc',2,4),
(10,'351531_image.jpg','Y7isy3ML5gZE1WnvwjkXc2.jpg',223547,5),
(12,'Excel cells.xlsx','19yPIqEwBgcrayWrIn6emg.xlsx',2,5),
(13,'image of 97157.jpg','uwqp4aiKKFMe7rOjiQBEPa.jpg',223547,5),
(14,'Nungnung-waterfall-Hello-Travel-1200x800.jpg','Apfv0YsSbqaECARGBwr_8T.jpg',333265,5),
(15,'places in the world.jpg','a7T_rg9h9JS9BKV3LYrTLY.jpg',242270,5),
(16,'report in this year.xlsx','3Wrn52Pwx3GmAA_fy1fi48.xlsx',2,5),
(17,'setting on hosting.txt','4zyzSELiyiqDMrWkCgabmp.txt',515,5),
(18,'Some document.doc','7C-WsdDOMRnkYY8p4eJ779.doc',2,5),
(19,'yii_bat_file.txt','GweNJmeAdJnrqUtKXUEGSF.txt',515,5),
(20,'archive.zip','BMdkOvzVrjMFf4fUQULZlb.zip',372,6),
(21,'places in the world.jpg','nb6p5b7xy8pHAdRs5JLRus.jpg',242270,6),
(22,'report in this year.xlsx','I__bC6fkUOoyJfjZ9kjmba.xlsx',2,6),
(23,'yii_bat_file.txt','YGhuEK3lnz3DvxE3HIHf6Q.txt',515,6),
(25,'archive.zip','QNKs_C-zGffZvwQIAMKmA6.zip',372,5)	;
#	TC`document`utf8_general_ci	;
CREATE TABLE `document` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COMMENT='Таблица документов'	;
#	TD`document`utf8_general_ci	;
INSERT INTO `document` VALUES 
(1,'Тестовый документ №1','Подробное описание тестового документа'),
(2,'Тестовый документ №2','Ещё одно описание'),
(3,'Документ не содержит файлов','Нет прикреплённых файлов'),
(4,'Документ с несколькими файлами','Здесь прикреплены несколько файлов'),
(5,'Документ с большим количеством файлов','Здесь есть несколько файлов в прикреплении'),
(6,'И ещё один документ с файлами','Здесь также есть несколько файлов в прикреплении')	;
